// Copyright 2016 Kristopher Mensing
// main.cpp
#include "library.h"
#include "book.h"

int main() { // literally a placeholder to make sure I can build it
	Library userLibrary; // testing out the library object
	Book newBook; // testing out the book object
	return 0; // to satisfy everyone
}
